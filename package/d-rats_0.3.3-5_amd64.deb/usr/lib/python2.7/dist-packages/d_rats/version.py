DRATS_VERSION = "0.3.3"

if __name__ == "__main__":
        print(DRATS_VERSION)
