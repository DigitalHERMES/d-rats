char *s = N_("<b>My Status</b>");
char *s = N_("<b>Stations</b>");
char *s = N_("<big><b>D*Query Tool</b></big>");
char *s = N_("A\n"
             "B\n"
             "C");
char *s = N_("Add filter");
char *s = N_("All\n"
             "File Transfers\n"
             "Form Transfers\n"
             "Position Reports\n"
             "Pings");
char *s = N_("Broadcast Text File");
char *s = N_("Chat");
char *s = N_("Command:");
char *s = N_("Connected to Internet");
char *s = N_("Containing text:");
char *s = N_("D-RATS");
char *s = N_("Delete Filter");
char *s = N_("Edit Map Source");
char *s = N_("Edit Map Sources");
char *s = N_("Event Log");
char *s = N_("Export Message");
char *s = N_("Files");
char *s = N_("Import Message");
char *s = N_("Local");
char *s = N_("Log");
char *s = N_("Main");
char *s = N_("Map");
char *s = N_("Message Templates");
char *s = N_("Messages");
char *s = N_("Name");
char *s = N_("Online\n"
             "Unattended");
char *s = N_("Ping Station");
char *s = N_("QSTs");
char *s = N_("Quick Messages");
char *s = N_("Send");
char *s = N_("Send D*Query");
char *s = N_("Show debug log");
char *s = N_("Show event type:");
char *s = N_("Show station list");
char *s = N_("Side Pane");
char *s = N_("Station:");
char *s = N_("This utility will allow you to send D*Query commands to the local gateway (if supported).  Type a command here (such as <i>wx</i>) and hit <b>Send</b>.  If successful, the result will appear in the chat window.");
char *s = N_("_Edit");
char *s = N_("_File");
char *s = N_("_Help");
char *s = N_("_View");
char *s = N_("a\n"
             "b\n"
             "c");
char *s = N_("a\n"
             "b\n"
             "c\n"
             "");
char *s = N_("gtk-about");
char *s = N_("gtk-add");
char *s = N_("gtk-cancel");
char *s = N_("gtk-clear");
char *s = N_("gtk-close");
char *s = N_("gtk-delete");
char *s = N_("gtk-edit");
char *s = N_("gtk-ok");
char *s = N_("gtk-preferences");
char *s = N_("gtk-remove");
