char *s = N_("1200\n"
             "2400\n"
             "4800\n"
             "9600\n"
             "19200\n"
             "38400\n"
             "57600\n"
             "115200");
char *s = N_("<b>Parameters</b>");
char *s = N_("AX.25");
char *s = N_("AX.25 Digi path (CALL1,CALL2,...)");
char *s = N_("Add a port");
char *s = N_("Address");
char *s = N_("Baud Rate");
char *s = N_("Digi Path");
char *s = N_("Enabled");
char *s = N_("Host Address");
char *s = N_("If the TNC is a multi-port unit, this\n"
             "specifies which port will be used\n"
             "(starting with 0 as the first one)");
char *s = N_("Name");
char *s = N_("Password");
char *s = N_("Port");
char *s = N_("Serial\n"
             "Network\n"
             "TNC\n"
             "Dongle\n"
             "AGWPE");
char *s = N_("Serial Port");
char *s = N_("TNC Port");
char *s = N_("The baud rate used to communicate with\n"
             "the TNC (not the rate over the air)");
char *s = N_("There are no parameters for dongle operation");
char *s = N_("Type");
char *s = N_("Username");
char *s = N_("When enabled, D-RATS will encapsulate\n"
             "its packets in AX.25 UI frames which can be\n"
             "passed through a digipeater");
char *s = N_("a\n"
             "b\n"
             "");
char *s = N_("page 1");
char *s = N_("page 2");
char *s = N_("page 3");
char *s = N_("page 4");
char *s = N_("page 5");
